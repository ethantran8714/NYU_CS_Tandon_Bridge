# Python Tips/Packages

## GraphViz Download

```python
pip install pygraphviz --install-option="--include-path=/usr/include/graphviz" --install-option="--library-path=/usr/lib/graphviz/"
```

## [**MISC] HomeBrew**

```python
pip install graphviz

pip install pygraphviz --install-option="--include-path=/usr/include/graphviz" --install-option="--library-path=/usr/lib/graphviz/"
```

## Anaconda Download

```python
export PATH="/Users/ethan/anaconda3/bin:$PATH"

cd /Users/Ethan/anaconda3/envs/
```